import os
from flask import Flask, render_template, request, jsonify
from anthropic import Anthropic

app = Flask(__name__)

# Set ANTHROPIC_API_KEY in your hosting provider's environment variables.
# Never put your secret API key in HTML or JavaScript.
api_key = os.environ.get("ANTHROPIC_API_KEY")
client = Anthropic(api_key=api_key) if api_key else None

@app.get("/")
def home():
    return render_template("index.html")

@app.post("/chat")
def chat():
    if client is None:
        return jsonify({"error": "На сервере ещё не настроен API-ключ Anthropic."}), 503

    data = request.get_json(silent=True) or {}
    message = (data.get("message") or "").strip()
    if not message:
        return jsonify({"error": "Напиши сообщение."}), 400
    if len(message) > 8000:
        return jsonify({"error": "Сообщение слишком длинное. Сократи его и попробуй снова."}), 400

    try:
        response = client.messages.create(
            model="claude-sonnet-4-5",
            max_tokens=1024,
            messages=[{"role": "user", "content": message}]
        )
        answer = "".join(
            block.text for block in response.content
            if getattr(block, "type", None) == "text"
        )
        return jsonify({"answer": answer})
    except Exception:
        app.logger.exception("Anthropic API request failed")
        return jsonify({"error": "Не удалось получить ответ от ИИ. Проверь API-ключ и настройки сервера."}), 500

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
